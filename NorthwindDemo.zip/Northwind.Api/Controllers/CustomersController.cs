using Microsoft.AspNetCore.Mvc;
using Northwind.Api.Services;

namespace Northwind.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CustomersController(CustomerService customerService) : ControllerBase
{
    [HttpGet]
    public IActionResult GetAll() => Ok(customerService.GetAllCustomers());

    [HttpGet("{customerId}")]
    public IActionResult GetById(string customerId)
    {
        var customer = customerService.GetCustomer(customerId);
        return customer is null ? NotFound() : Ok(customer);
    }
}
