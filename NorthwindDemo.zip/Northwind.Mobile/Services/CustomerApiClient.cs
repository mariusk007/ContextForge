using System.Net.Http.Json;
using Northwind.Core.Models;

namespace Northwind.Mobile.Services;

// Talks to Northwind.Api's CustomersController from the mobile app.
public class CustomerApiClient(HttpClient httpClient)
{
    public async Task<List<Customer>> GetCustomersAsync() =>
        await httpClient.GetFromJsonAsync<List<Customer>>("api/customers") ?? [];

    public async Task<Customer?> GetCustomerAsync(string customerId) =>
        await httpClient.GetFromJsonAsync<Customer>($"api/customers/{customerId}");
}
