using Northwind.Core.Models;
using Northwind.Data.Repositories;

namespace Northwind.Api.Services;

public class OrderService(IOrderRepository orderRepository)
{
    public IEnumerable<Order> GetAllOrders() => orderRepository.GetAll();

    public IEnumerable<Order> GetOrdersForCustomer(string customerId) =>
        orderRepository.GetByCustomerId(customerId);
}
