using Northwind.Core.Models;
using Northwind.Mobile.Services;

namespace Northwind.Mobile.ViewModels;

public class OrderViewModel(OrderApiClient orderApiClient)
{
    public List<Order> Orders { get; private set; } = [];

    public async Task LoadAsync(string customerId)
    {
        Orders = await orderApiClient.GetOrdersForCustomerAsync(customerId);
    }
}
