using Northwind.Core.Models;

namespace Northwind.Data.Repositories;

public class CustomerRepository : ICustomerRepository
{
    private static readonly List<Customer> _customers =
    [
        new() { CustomerId = "ALFKI", CompanyName = "Alfreds Futterkiste", ContactName = "Maria Anders", City = "Berlin", Country = "Germany" },
        new() { CustomerId = "ANATR", CompanyName = "Ana Trujillo Emparedados", ContactName = "Ana Trujillo", City = "Mexico City", Country = "Mexico" },
        new() { CustomerId = "AROUT", CompanyName = "Around the Horn", ContactName = "Thomas Hardy", City = "London", Country = "UK" }
    ];

    public IEnumerable<Customer> GetAll() => _customers;

    public Customer? GetById(string customerId) =>
        _customers.FirstOrDefault(c => c.CustomerId == customerId);
}
