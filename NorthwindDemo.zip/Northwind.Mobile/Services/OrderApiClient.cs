using System.Net.Http.Json;
using Northwind.Core.Models;

namespace Northwind.Mobile.Services;

// Talks to Northwind.Api's OrdersController from the mobile app.
public class OrderApiClient(HttpClient httpClient)
{
    public async Task<List<Order>> GetOrdersForCustomerAsync(string customerId) =>
        await httpClient.GetFromJsonAsync<List<Order>>($"api/orders/customer/{customerId}") ?? [];
}
