using Northwind.Core.Models;

namespace Northwind.Data.Repositories;

public interface ICustomerRepository
{
    IEnumerable<Customer> GetAll();
    Customer? GetById(string customerId);
}
