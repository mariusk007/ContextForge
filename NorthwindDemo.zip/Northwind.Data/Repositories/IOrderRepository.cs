using Northwind.Core.Models;

namespace Northwind.Data.Repositories;

public interface IOrderRepository
{
    IEnumerable<Order> GetAll();
    IEnumerable<Order> GetByCustomerId(string customerId);
}
