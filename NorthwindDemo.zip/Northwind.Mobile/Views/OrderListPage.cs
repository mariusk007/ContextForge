using Northwind.Mobile.ViewModels;

namespace Northwind.Mobile.Views;

public class OrderListPage(OrderViewModel viewModel)
{
    public async Task OnAppearingAsync(string customerId)
    {
        await viewModel.LoadAsync(customerId);
    }

    public string Render() =>
        string.Join(Environment.NewLine, viewModel.Orders.Select(o => $"Order #{o.OrderId} - {o.OrderDate:d}"));
}
