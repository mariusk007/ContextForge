using Northwind.Mobile.ViewModels;

namespace Northwind.Mobile.Views;

// Stand-in for a MAUI/Xamarin page - kept as plain C# so the demo
// solution builds without mobile workloads installed.
public class CustomerListPage(CustomerViewModel viewModel)
{
    public async Task OnAppearingAsync()
    {
        await viewModel.LoadAsync();
    }

    public string Render() =>
        string.Join(Environment.NewLine, viewModel.Customers.Select(c => $"{c.CompanyName} ({c.City})"));
}
