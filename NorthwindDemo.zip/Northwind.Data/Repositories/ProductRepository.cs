using Northwind.Core.Models;

namespace Northwind.Data.Repositories;

public class ProductRepository : IProductRepository
{
    private static readonly List<Product> _products =
    [
        new() { ProductId = 11, ProductName = "Queso Cabrales", UnitPrice = 21.00m, UnitsInStock = 22 },
        new() { ProductId = 42, ProductName = "Singaporean Noodles", UnitPrice = 14.00m, UnitsInStock = 26 }
    ];

    public IEnumerable<Product> GetAll() => _products;
}
