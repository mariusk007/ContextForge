using Northwind.Core.Models;

namespace Northwind.Data.Repositories;

public class OrderRepository : IOrderRepository
{
    private static readonly List<Order> _orders =
    [
        new()
        {
            OrderId = 10248,
            CustomerId = "ALFKI",
            OrderDate = new DateTime(2026, 1, 4),
            Items = [ new() { ProductId = 11, ProductName = "Queso Cabrales", Quantity = 12, UnitPrice = 14.00m } ]
        },
        new()
        {
            OrderId = 10249,
            CustomerId = "ANATR",
            OrderDate = new DateTime(2026, 1, 5),
            Items = [ new() { ProductId = 42, ProductName = "Singaporean Noodles", Quantity = 40, UnitPrice = 9.80m } ]
        }
    ];

    public IEnumerable<Order> GetAll() => _orders;

    public IEnumerable<Order> GetByCustomerId(string customerId) =>
        _orders.Where(o => o.CustomerId == customerId);
}
