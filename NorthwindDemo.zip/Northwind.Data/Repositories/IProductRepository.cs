using Northwind.Core.Models;

namespace Northwind.Data.Repositories;

public interface IProductRepository
{
    IEnumerable<Product> GetAll();
}
