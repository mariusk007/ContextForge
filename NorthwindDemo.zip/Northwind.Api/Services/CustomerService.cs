using Northwind.Core.Models;
using Northwind.Data.Repositories;

namespace Northwind.Api.Services;

public class CustomerService(ICustomerRepository customerRepository)
{
    public IEnumerable<Customer> GetAllCustomers() => customerRepository.GetAll();

    public Customer? GetCustomer(string customerId) => customerRepository.GetById(customerId);
}
