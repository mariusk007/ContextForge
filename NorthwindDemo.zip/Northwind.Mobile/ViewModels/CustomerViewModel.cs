using Northwind.Core.Models;
using Northwind.Mobile.Services;

namespace Northwind.Mobile.ViewModels;

public class CustomerViewModel(CustomerApiClient customerApiClient)
{
    public List<Customer> Customers { get; private set; } = [];

    public async Task LoadAsync()
    {
        Customers = await customerApiClient.GetCustomersAsync();
    }
}
