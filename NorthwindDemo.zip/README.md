# NorthwindDemo

A small 4-project solution built to demo [ContextForge](https://github.com/mariusk007/ContextForge).

## Why this exists

In a real solution, a feature like "Customer" (or "NetSuite", "Tracker", etc.)
rarely lives in one place — it's spread across your data layer, your API,
and your mobile/frontend client. Scrolling through the whole solution to
mentally reassemble "everything to do with Customer" is slow, and pasting
the *whole* solution into an AI chat blows the context window with
unrelated Order/Product code.

This solution intentionally spreads the **Customer** feature across all
four projects, sitting alongside similarly-spread **Order** and **Product**
code as noise:

| Project | Layer | Customer-related files |
|---|---|---|
| Northwind.Core | shared models | `Models/Customer.cs` |
| Northwind.Data | repositories | `Repositories/ICustomerRepository.cs`, `Repositories/CustomerRepository.cs` |
| Northwind.Api | backend | `Controllers/CustomersController.cs`, `Services/CustomerService.cs` |
| Northwind.Mobile | frontend | `ViewModels/CustomerViewModel.cs`, `Views/CustomerListPage.cs`, `Services/CustomerApiClient.cs` |

## Demo flow

1. Open ContextForge and browse to this solution's root folder.
2. Type `customer` in the filter box.
3. Watch the tree collapse down to just the 7 Customer-related files —
   spanning all 4 projects — with everything else (Order, Product,
   Program.cs, csproj files) filtered out.
4. Check the results, copy the generated context, and paste straight into
   an AI chat with zero unrelated noise.

Swap the filter to `order` to see the same thing happen for the Order
feature instead.
