using Microsoft.AspNetCore.Mvc;
using Northwind.Data.Repositories;

namespace Northwind.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ProductsController(IProductRepository productRepository) : ControllerBase
{
    [HttpGet]
    public IActionResult GetAll() => Ok(productRepository.GetAll());
}
