using Microsoft.AspNetCore.Mvc;
using Northwind.Api.Services;

namespace Northwind.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController(OrderService orderService) : ControllerBase
{
    [HttpGet]
    public IActionResult GetAll() => Ok(orderService.GetAllOrders());

    [HttpGet("customer/{customerId}")]
    public IActionResult GetByCustomer(string customerId) => Ok(orderService.GetOrdersForCustomer(customerId));
}
